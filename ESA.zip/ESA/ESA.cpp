//
// Created by jose on 15/06/18.
//

#include <cmath>
#include "ESA.h"
#include <set>

using namespace realea;

pair<int,int> ESA::AjustarRatio(int N,int itera){
    pair<int,int> c_h(N-1,1);
    pair<int,int> c_m(N/2,N/2);
    pair<int,int> c_l(1,N-1);
    double ch_value,cm_value,cl_value;
    double ch_sum = 0,cm_sum = 0,cl_sum = 0;
    tChromosomeReal aux;
    bool ch = false,cm = false,cl = false;

    int it = 5;
    int cuantas = 0;
    int llamadas = itera/it/3;

    while((c_h.first-c_l.first > 2 || c_m.first-c_l.first > 1 || c_m.first-c_h.first > 1) && cuantas < itera){
        if(!ch) ch_sum = 0;
        if(!cm) cm_sum = 0;
        if(!cl) cl_sum = 0;
        for(int i = 0; i < it; i++){
            if(!ch) {
                aux = apply(c_h.first, c_h.second, llamadas);
                cuantas += llamadas;
                ch_value = m_problem->eval(aux);
                ch_sum += ch_value / it;
                ch = (i+1==it)?true:false;
            }

            if(!cm) {
                aux = apply(c_m.first, c_m.second, llamadas);
                cuantas += llamadas;
                cm_value = m_problem->eval(aux);
                cm_sum += cm_value / it;
                cm = (i+1==it)?true:false;
            }

            if(!cl) {
                aux = apply(c_l.first, c_l.second, llamadas);
                cuantas += llamadas;
                cl_value = m_problem->eval(aux);
                cl_sum += cl_value / it;
                cl = (i+1==it)?true:false;
            }
        }

        if(ch_sum < cm_sum && ch_sum < cl_sum){
            c_l.first = c_m.first;
            c_l.second = c_m.second;
            cl_sum = cm_sum;

            c_m.first = (c_m.first+c_h.first)/2;
            c_m.second = N-c_m.first;
            cm = false;
        }
        else if(cl_sum < cm_sum && cl_sum < ch_sum){
            c_h.first = c_m.first;
            c_h.second = c_m.second;
            ch_sum = cm_sum;

            c_m.first = (c_m.first+c_l.first)/2;
            c_m.second = N-c_m.first;
            cm = false;
        }
        else if(ch_sum < cm_sum && cl_sum < cm_sum){
            if(ch_sum < cl_sum){
                c_m.first = (c_m.first+c_h.first)/2;
                c_m.second = N-c_m.first;
                cm = false;
            }else{
                c_m.first = (c_m.first+c_l.first)/2;
                c_m.second = N-c_m.first;
                cm = false;
            }
        }
        else if(cm_sum < ch_sum && cm_sum < cl_sum){
            c_h.first = (c_m.first+c_h.first)/2;
            c_h.second = N-c_h.first;
            ch = false;

            c_l.first = (c_m.first+c_l.first)/2;
            c_l.second = N-c_l.first;
            cl = false;
        }
    }

    return c_m;
}

int ESA::getInitRandomPop(vector<elephant> &Mpop, unsigned popsizemachos, vector<elephant> &Hpop, int popsizehembras,int itera){
    Mpop.clear();
    Hpop.clear();
    int res = itera;


    for(int i=0; i < popsizemachos; i++){
        tChromosomeReal newSol(m_problem->getDimension());
        getInitRandom(newSol);
        elephant newEl(0,newSol,m_problem->eval(newSol),1);
        Mpop.push_back(newEl);
    }

    tChromosomeReal bestMacho = Mpop[0].pos;
    double value = Mpop[0].valor;

    for(int i=0; i < popsizemachos; i++){
        if(Mpop[i].valor < value){
            bestMacho = Mpop[i].pos;
            value = Mpop[i].valor;
        }
    }
///////////////////////////////////////////////////////////

    /*for(int i=0; i < popsizehembras; i++){
        elephant newEl(1,bestMacho,value,1);
        Hpop.push_back(newEl);
    }*/

    ////////////////////////////////////////////////////////

    /*for(int i=0; i < popsizehembras; i++){
      tChromosomeReal newSol(dim);
      getInitRandom(random, domain, newSol);
      elephant newEl(0,newSol,problema->eval(newSol),1);
      Hpop.push_back(newEl);
    }*/

    /////////////////////////////////////////////////////////
    ILocalSearch *ls;
    ILSParameters *ls_options;

    CMAESHansen *cmaes = new CMAESHansen("cmaesinit.par");
    cmaes->searchRange(0.1);

    ls = cmaes;
    ls->setProblem(m_problem);
    ls->setRandom(m_random);

    ls_options = ls->getInitOptions(bestMacho);

    res = ls->apply(ls_options, bestMacho, value, itera);

    delete(ls);

    for(int i=0; i < popsizehembras; i++){
        elephant newEl(1,bestMacho,value,1);
        Hpop.push_back(newEl);
    }

    return res;
}

void ESA::getInitRandom(tChromosomeReal &crom) {
    tReal min, max;


    for (unsigned i = 0; i < crom.size(); ++i) {
        m_problem->getDomain()->getValues(i, &min, &max, true);
        crom[i] = m_random->randreal(min, max);
    }

}

tChromosomeReal ESA::apply(int Machos, int Hembras, unsigned iteraReal){
    int itera = 0.9*iteraReal;
    double radioMachos = m_problem->getDimension()*2;
    int total = (Machos+Hembras);
    int iterBL = total*0.4;
    limitacionVida = itera/iterBL/10;
    if(limitacionVida == 0) limitacionVida = itera/10;
    vector<elephant> Mpop;
    vector<elephant> Hpop;
    int BLmal = 0;

    itera = iteraReal - getInitRandomPop(Mpop,Machos,Hpop,Hembras,iteraReal-itera);

    Inicializar(Mpop,Hpop);

    while(iteraciones < itera){

        for(int itM = 0; itM < Machos ; itM++){

            bool salir = false;
            for(int j = 0; j < Machos && !salir;j++){

                if(j != itM && DistanciaEuclidea(Mpop,itM,j) < radioMachos){
                    EscapaElefante(Mpop,j,itM,radioMachos);
                    salir = true;
                }
            }

            Mpop[itM] = GenerarNuevaPosicion(0,Mpop[itM],radioMachos);

        }
        ActualizarMejor(0,Mpop);

        double ant = lider->valor;
        iteraciones += BusquedaLocalLider(iterBL);
        double des = lider->valor;
        if(ant-des==0){
            BLmal++;
        }
        else{
            BLmal = 0;
        }

        if(BLmal > 2*m_problem->getDimension()){
            for(int i = 0; i < Hpop.size(); i++){
                Hpop[i].valor = valueMejorMachoGlobal;
                Hpop[i].pos = mejorMachoGlobal;
            }

            mejorMachoGlobal = mejorMacho->pos;
            valueMejorMachoGlobal = mejorMacho->valor;
        }

        for(int itH = 0 ; itH < Hembras; itH++){
            if(lider != &Hpop[itH]){
                Hpop[itH] = GenerarNuevaPosicion(1,Hpop[itH],radioMachos);

            }
        }
        ActualizarMejor(1,Hpop);

        for(int j = 0; j < Machos; j++){
            if(DebeMorir(Mpop[j])) {
                CrearNuevoElefante(Mpop, Hpop, j, 0);
            }
        }

        for(int j = 0; j < Hembras; j++){
            if(DebeMorir(Hpop[j])){
                CrearNuevoElefante(Mpop,Hpop,j,1);
            }
        }


        if(mejorLocal->valor < valueMejorGlobal){
            mejorGlobal = mejorLocal->pos;
            valueMejorGlobal = mejorLocal->valor;
        }

        if(mejorMacho->valor < valueMejorMachoGlobal && mejorMacho->valor > lider->valor){
            mejorMachoGlobal = mejorMacho->pos;
            valueMejorMachoGlobal = mejorMacho->valor;
        }

        CambiarPosiciones(Hpop);
    }

    return mejorGlobal;
}

void ESA::Inicializar(vector<elephant> &Mpop, vector<elephant> &Hpop) {
    mejorMacho = &Mpop[0];
    mejorLocal = &Mpop[0];
    lider = &Hpop[0];
    iteraciones = 0;

    for(int i = 0; i < Mpop.size(); i++){
        if(Mpop[i].valor < mejorMacho->valor){
            mejorMacho = &Mpop[i];
        }
    }
    mejorLocal = mejorMacho;
    mejorMachoGlobal = mejorMacho->pos;
    valueMejorMachoGlobal = mejorMacho->valor;

    for(int i = 0; i < Hpop.size(); i++){
        if(Hpop[i].valor < lider->valor){
            lider = &Hpop[i];
        }

        if(Hpop[i].valor < mejorLocal->valor){
            mejorLocal = &Hpop[i];
        }
    }

    mejorGlobal = mejorLocal->pos;
    valueMejorGlobal = mejorLocal->valor;
}

elephant ESA::GenerarNuevaPosicion(int sexo, const elephant &elefante,double radioMachos){
    tChromosomeReal nuevoElefante(m_problem->getDimension());
    tChromosomeReal antElefante = elefante.pos;
    tChromosomeReal liderElefante = lider->pos;

    if(sexo==0){ //Macho
        unsigned int dimensiones = m_problem->getDimension();

        /*double vector[dimensiones+2];
        double sum = 0;

        for(int i = 0; i < dimensiones+2; i++){
            vector[i] = m_random->normal(0.4);
            sum+=vector[i]*vector[i];
        }

        double norma = sqrt(sum);

        tReal min,max;
        for(int i = 0; i < dimensiones; i++){
            nuevoElefante[i] = (elefante.pos[i]+(vector[i]/norma*radioMachos));
            m_problem->getDomain()->getValues(i, &min, &max, true);
            if(nuevoElefante[i] > max){
                nuevoElefante[i] = max;
            }
            else if(nuevoElefante[i] < min){
                nuevoElefante[i] = min;
            }
        }*/

        /////////////////////////////////////////////////////////////////////

        /*for(int i = 0; i < dimensiones; i++){
            double value = (1.0-2.0*m_random->randreal(0,1));
            nuevoElefante[i] = antElefante[i]+value*radioMachos;
        }*/

        /////////////////////////////////////////////////////////////////////

        /*for(int i = 0; i < dimensiones; i++){
            double value = LevyValue(1.7);
            nuevoElefante[i] = antElefante[i]+value;
        }*/

        int rand = m_random->randint(0,nuevoElefante.size());

        nuevoElefante[rand] = antElefante[rand]+LevyValue(1.7);

        /////////////////////////////////////////////////////////////////////

        /*tReal min,max;
        for(int i = 0; i < dimensiones; i++){
            m_problem->getDomain()->getValues(i, &min, &max, true);
            double value = m_random->normal(0.3)*max;
            nuevoElefante[i] = antElefante[i]+value;
        }*/

        /////////////////////////////////////////////////////////////////////
        /*double mu = 0.2;
        double sigma = 2.0;
        double Dt = 0.1;
        double stdev = sqrt(Dt)*sigma;

        for(int i = 0; i < dimensiones; i++){
            double value = (m_random->normal(stdev)+(mu*Dt))*100;
            nuevoElefante[i] = antElefante[i]+value;
        }*/
    }
    else{ // Hembra
        double alpha = 0.5; //influencia de la lider.
        double r = m_random->randreal(0,1);

        for(int i = 0; i < elefante.pos.size(); i++){
            double value = (antElefante[i]+alpha*(liderElefante[i]-antElefante[i])*r);
            nuevoElefante[i] = value;
        }
    }

    tReal min,max;
    for(int i = 0; i < nuevoElefante.size(); i++) {
        m_problem->getDomain()->getValues(i, &min, &max, true);
        if (nuevoElefante[i] > max) {
            nuevoElefante[i] = max;
        } else if (nuevoElefante[i] < min) {
            nuevoElefante[i] = min;
        }
    }

    /*
     * Comentar o descomentar la parte de la vitalidad para utilizar o no esta mejora
     * En caso de comentarla, sumar siempre 1 a la vida del elefante.
     */
    int vitalidad = 1;
    if((elefante.valor-m_problem->getOptime())/log(elefante.vida) < 0.1) vitalidad = -1;
    else if((elefante.valor-m_problem->getOptime())/log(elefante.vida) > 2) vitalidad = 2;

    elephant res(sexo,nuevoElefante,m_problem->eval(nuevoElefante),elefante.vida+vitalidad);
    iteraciones++;
    return res;
}

double ESA::DistanciaEuclidea(const vector<elephant> &pop, int uno, int dos){
    double sum = 0;
    for(int i = 0; i < pop[uno].pos.size(); i ++){
        sum += (pop[uno].pos[i] - pop[dos].pos[i])*(pop[uno].pos[i] - pop[dos].pos[i]);
    }
    return sqrt(sum);
}

void ESA::ActualizarMejor(int sexo,vector<elephant> &pop){

    if(sexo == 0){  //Machos
        mejorLocal = &pop[0];

        for(int i = 0; i < pop.size(); i++){
            if(pop[i].valor < mejorLocal->valor){
                mejorLocal = &pop[i];
            }
        }
        mejorMacho = mejorLocal;
    }
    else{   //Hembras
        lider = &pop[0];
        for(int i = 0; i < pop.size(); i++){
            if(pop[i].valor < mejorLocal->valor){
                mejorLocal = &pop[i];
            }
            if(pop[i].valor < lider->valor){
                lider = &pop[i];
            }
        }
    }
}

int ESA::BusquedaLocalLider(int iter){
    ILocalSearch *ls;
    ILSParameters *ls_options;

    /*CMAESHansen *cmaes = new CMAESHansen("cmaesinit.par");
    cmaes->searchRange(0.1);*/

    SolisWets *sw = new SolisWets();
    sw->setDelta(0.2);

    ls = sw;
    //ls = new SimplexDim();
    ls->setProblem(m_problem);
    ls->setRandom(m_random);

    ls_options = ls->getInitOptions(lider->pos);

    unsigned evals = ls->apply(ls_options, lider->pos, lider->valor, iter);

    delete(sw);

    tReal min,max;
    for(int i = 0; i < lider->pos.size(); i++){
        m_problem->getDomain()->getValues(i, &min, &max, true);
        if(lider->pos[i] > max){
            lider->pos[i] = max;
        }
        else if(lider->pos[i] < min){
            lider->pos[i] = min;
        }
    }

    return evals;
}

bool ESA::DebeMorir(const elephant &el){
    if(m_random->randreal(0,1) > pow(el.vida/limitacionVida,3)) return false;
    return true;
}

void ESA::CrearNuevoElefante(vector<elephant> &Mpop, vector<elephant> &Hpop, int pos, int sexo){
    tChromosomeReal nuevo(m_problem->getDimension());

    if(sexo == 0){ //Macho
        tChromosomeReal madre = Hpop[m_random->randint(0,Hpop.size()-1)].pos;
        tChromosomeReal padre = Mpop[pos].pos;
        tChromosomeReal liderc = lider->pos;

        for(int i = 0; i < padre.size(); i++){
            nuevo[i] = (0.6*madre[i]+0.3*padre[i]+0.1*liderc[i]);
        }

        Mpop[pos].pos = nuevo;
        Mpop[pos].vida = 1;
        Mpop[pos].sexo = sexo;
        Mpop[pos].valor = m_problem->eval(nuevo);

        if(Mpop[pos].valor < mejorMacho->valor){
            mejorMacho = &Mpop[pos];
        }

        if(Mpop[pos].valor < mejorLocal->valor){
            mejorLocal = &Mpop[pos];
        }
    }
    else{   //Hembra
        tChromosomeReal madre = Hpop[pos].pos;
        int m = m_random->randint(0,Mpop.size()-1);
        tChromosomeReal padre = Mpop[m].pos;
        tChromosomeReal liderc = lider->pos;

        for(int i = 0; i < madre.size(); i++){
            double valor = 0.6*madre[i]+0.3*padre[i]+0.1*liderc[i];
            nuevo[i] = (valor);
        }

        Hpop[pos].pos = nuevo;
        Hpop[pos].vida = 1;
        Hpop[pos].sexo = sexo;
        Hpop[pos].valor = m_problem->eval(nuevo);

        if(Hpop[pos].valor < lider->valor){
            lider = &Hpop[pos];
        }

        if(Hpop[pos].valor < mejorLocal->valor){
            mejorLocal = &Hpop[pos];
        }
    }
    iteraciones++;
}

void ESA::EscapaElefante(vector<elephant> &Mpop,int i, int j,double radioMachos){
    int bueno,malo;

    if(Mpop[i].valor > Mpop[j].valor){
        bueno = j;
        malo = i;
    }
    else{
        bueno = i;
        malo = j;
    }

    int elementos = (int)(0.4*(double)Mpop[bueno].pos.size());

    tReal min,max;
    set<int> posiciones;
    int pos;
    for(int i = 0; i < elementos; i++){
        m_problem->getDomain()->getValues(i, &min, &max, true);

        do{
            pos = m_random->randint(0,Mpop[malo].pos.size()-1);
        }while(posiciones.find(pos) != posiciones.end());

        posiciones.insert(pos);
        Mpop[malo].pos[pos] = Mpop[malo].pos[pos]+LevyValue(1.7);

        if(Mpop[malo].pos[pos] > max){
            Mpop[malo].pos[pos] = max;
        }
        else if(Mpop[malo].pos[pos] < min){
            Mpop[malo].pos[pos] = min;
        }
    }

    Mpop[malo].valor = m_problem->eval(Mpop[malo].pos);
    iteraciones++;
}

void ESA::CambiarPosiciones(vector<elephant> &Hpop){
    if(mejorMacho->valor < lider->valor){
        for(int i = 0; i < Hpop.size(); i++){
            Hpop[i].valor = mejorMacho->valor;
            Hpop[i].pos = mejorMacho->pos;
        }

        /*lider->pos = mejorMacho;
        lider->valor = mejorMacho->valor;*/
    }
}

// mu debe estar entre 1 y 3
double ESA::LevyValue(double mu) {
    double X = m_random->randreal(-M_PI/2.0, M_PI/2.0);
    double value;
    do{
        value = m_random->randreal(0,1);
    }while(value==0);

    double Y = -log(value);
    double alpha = mu - 1.0;

    double Z = 	(sin(alpha * X) / pow( cos(X) , 1.0 / alpha )) * pow(cos((1.0-alpha) * X) / Y, (1.0 - alpha) / alpha);
    return Z;
}