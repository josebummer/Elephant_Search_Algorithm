//
// Created by jose on 15/06/18.
//

#ifndef _ESA_H
#define _ESA_H


#include "problem.h"
#include "random.h"
#include "define.h"
#include "elephant.h"
#include "localsearch.h"
#include "solis.h"
#include "simplex.h"
#include "cmaeshan.h"

namespace realea {

    class ESA {
    public:
        tChromosomeReal apply(int Machos, int Hembras, unsigned iteraReal);
        pair<int,int> AjustarRatio(int N, int itera);
        int getInitRandomPop(vector<elephant> &Mpop, unsigned popsizemachos, vector<elephant> &Hpop, int popsizehembras,int itera);
        void getInitRandom(tChromosomeReal &crom);

        void setProblem(Problem *problem) {
            m_problem = problem;
            setEval(problem);
        }

        void setRandom(Random *random) {
            m_random = random;
        }

        void setEval(IEval *eval) {
            m_eval = eval;
        }


    protected:
        Random *m_random; /**< The current randomgeneration numbers */
        IEval *m_eval; /** The current evaluation function */
        Problem *m_problem; /**< The current problem */
        tChromosomeReal mejorGlobal;
        double valueMejorGlobal;
        elephant *mejorLocal;
        elephant *lider;
        int limitacionVida;
        elephant *mejorMacho;
        int iteraciones = 0;
        tChromosomeReal mejorMachoGlobal;
        double valueMejorMachoGlobal;

    private:
        elephant GenerarNuevaPosicion(int sexo, const elephant &elefante, double radioMachos);
        double DistanciaEuclidea(const vector<elephant> &pop, int uno, int dos);
        void ActualizarMejor(int sexo, vector<elephant> &pop);
        int BusquedaLocalLider(int iter);
        bool DebeMorir(const elephant &el);
        void CrearNuevoElefante(vector<elephant> &Mpop, vector<elephant> &Hpop, int pos, int sexo);
        void EscapaElefante(vector<elephant> &Mpop,int i, int j,double radioMachos);
        void CambiarPosiciones(vector<elephant> &Hpop);
        double LevyValue(double mu);
        void Inicializar(vector<elephant> &Mpop, vector<elephant> &Hpop);
    };

}



#endif //_ESA_H
