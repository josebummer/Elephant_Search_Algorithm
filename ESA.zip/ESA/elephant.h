//
// Created by jose on 15/06/18.
//

#ifndef LS_ELEPHANT_H
#define LS_ELEPHANT_H

#include "define.h"

namespace realea {


    class elephant {
    public:
        elephant();
        elephant(int s, const tChromosomeReal &v, double fitness, int vid);

        int vida;
        int sexo; //0 Macho, 1 Hembra
        tChromosomeReal pos;
        double valor;
    };

}
#endif //LS_ELEPHANT_H
