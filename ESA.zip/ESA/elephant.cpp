//
// Created by jose on 15/06/18.
//

#include "elephant.h"

using namespace realea;

elephant::elephant(int s, const tChromosomeReal &v, double fitness,int vid){
    sexo = s;
    vida = vid;
    pos = v;
    valor = fitness;
}

elephant::elephant() {
    sexo=0;
    vida=0;
    valor = 9999999;
}