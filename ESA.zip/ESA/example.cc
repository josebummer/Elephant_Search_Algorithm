#include "problemcec2014.h"
#include "problem.h"
#include "solis.h"
#include "simplex.h"
#include "cmaeshan.h"
#include "random.h"
#include "srandom.h"
#include "domain.h"
#include "localsearch.h"
#include "ESA.h"
#include <iostream>


using namespace realea;

int main(int argc, char *argv[]) {

  int dim = 10;

  DomainRealPtr domain;
  ProblemCEC2014 cec2014(dim);
  vector<elephant> machos;
  vector<elephant> hembras;
  tChromosomeReal res;
  ESA *alg;
  alg = new ESA();
  double suma = 0;

  int seed=time(NULL);
  Random random(new SRandom(seed));

  for(int i = 1; i <= 20; i++){
    int fun = i;

    // Get the function fun for dimension dim
    ProblemPtr problem = cec2014.get(fun);
    // Domain is useful for clipping solutions
    domain = problem->getDomain();
    // Get the maximum evaluations from the problem
    unsigned max_evals = problem->getMaxEval();

    alg->setRandom(&random);
    alg->setProblem(problem.get());

    suma = 0;
    /*
    Descomentar y comentar la linea que no se quiera utilizar
    Este ratio se autocalcula utilizando un porcentaje del total de las evaluaciones.
     */
    //pair<int,int> ratio = alg->AjustarRatio(60,0.3*max_evals);
    /*
    Este otro asignar el ratio como queramos, siendo el prederminado 1:4
     */
    pair<int,int> ratio(12,48);
    for(int j = 0 ; j < 25; j++){

      res = alg->apply(ratio.first,ratio.second,max_evals);
      suma += problem->eval(res)/25;

    }

    /*cout << endl << "Funcion " << i << endl;
    cout << "Iteraciones: " << max_evals << endl;
    cout << "ESA:" << endl;*/
    cout << std::scientific <<suma << endl;
    // cout << std::scientific << problem->getOptime() << endl;
  }
  delete alg;

  return 0;
}

